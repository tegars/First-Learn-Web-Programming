<?php
$server_name="mysql2.000webhost.com";
$server_user="a1218809_user";
$server_password="123456id";
$database_name="a1218809_latihan";
$server_connect=mysql_connect($server_name,$server_user,$server_password)or die("Tidak bisa membuat koneksi ke server");
$database_select=mysql_select_db($database_name,$server_connect)or die ("Tidak bisa menggunakan database");
?>